package entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Video")
public class Videos {

    @Id
    @Column(name = "Id")
    private String id;

    @Column(name = "Titile")
    private String titile;

    @Column(name = "Poster")
    private String poster;

    @Column(name = "Views")
    private Integer views;

    @Column(name = "Description")
    private String description;

    @Column(name = "Active")
    private Boolean active;

    @Column(name = "Link")
    private String link;

    // =====================================
    // Constructors
    // =====================================

    public Videos() {
    }

    public Videos(String id, String titile, String poster, Integer views,
                  String description, Boolean active, String link) {
        this.id = id;
        this.titile = titile;
        this.poster = poster;
        this.views = views;
        this.description = description;
        this.active = active;
        this.link = link;
    }

    // =====================================
    // Getters & Setters
    // =====================================

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitile() {
        return titile;
    }

    public void setTitile(String titile) {
        this.titile = titile;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public Integer getViews() {
        return views;
    }

    public void setViews(Integer views) {
        this.views = views;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
