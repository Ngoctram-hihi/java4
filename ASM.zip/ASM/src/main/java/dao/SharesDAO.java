package dao;

import entity.Shares;

public interface SharesDAO extends CrudDAO<Shares, Long>{

}
