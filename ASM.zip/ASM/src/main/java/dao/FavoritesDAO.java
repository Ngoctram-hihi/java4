package dao;

import java.util.List;

import entity.Favorites;

public interface FavoritesDAO extends CrudDAO<Favorites, Long>{
	List<Favorites> findByUserId(String userId);
	List<Favorites> findPageSize(int pageNumber, int pageSize);
	long count();
}
