package servlet;

import java.io.IOException;
import java.util.List;

import dao.FavoritesDAO;
import daoimpl.FavoritesDAOImpl;
import entity.Favorites;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/favorites")
public class FavoriteServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		if(session == null || session.getAttribute("user") == null) {
        	req.setAttribute("message", "Bạn chưa đăng nhập!");
            req.getRequestDispatcher("/Home/Login.jsp").forward(req, resp);
            return;
        }

		User users = (User) session.getAttribute("user");
		FavoritesDAO favdao = new FavoritesDAOImpl();
		List<Favorites> favList = favdao.findByUserId(users.getId());
		req.setAttribute("favorites", favList);
		req.getRequestDispatcher("/Home/Favorites.jsp").forward(req, resp);
	}
}
