package servlet;

import java.io.IOException;

import dao.UserDAO;
import daoimpl.UserDAOImpl;
import entity.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/crud/login")
public class LoginServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String id = req.getParameter("id");
        String pass = req.getParameter("password");

        UserDAO dao = new UserDAOImpl();
        User user = dao.findById(id);

        if (user != null && user.getPassword().equals(pass)) {
            req.getSession().setAttribute("user", user);
            resp.sendRedirect("index");
        } else {
            req.setAttribute("error", "Invalid login!");
            req.getRequestDispatcher("/Home/Login.jsp").forward(req, resp);
        }

	}
}
