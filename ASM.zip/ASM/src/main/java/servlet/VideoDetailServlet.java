package servlet;

import java.io.IOException;

import dao.VideosDAO;
import daoimpl.VideosDAOImpl;
import entity.Videos;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/crud/detail")
public class VideoDetailServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Videos video= new Videos();
		VideosDAO viddao = new VideosDAOImpl();
		String id = req.getParameter("id");
		video = viddao.findById(id);
		String https = video.getLink().substring(0, 24);
		String videoLink = video.getLink().substring(32, 43);
		req.setAttribute("video", video);
		req.setAttribute("videoLink",https + "embed/" + videoLink);
		req.getRequestDispatcher("/Home/Video.jsp").forward(req, resp);
	}
}
