﻿CREATE DATABASE ASM;

USE ASM;

CREATE TABLE Users(
	Id VARCHAR(10) PRIMARY KEY,
	Password VARCHAR(50),
	Email VARCHAR(50),
	Fullname NVARCHAR(50),
	Admin BIT
);

CREATE TABLE Video(
	Id VARCHAR(10) PRIMARY KEY,
	Titile NVARCHAR(100),
	Poster NVARCHAR(50),
	Views INT,
	Description NVARCHAR(50),
	Active BIT,
	Link VARCHAR(100)
);

CREATE TABLE Favorite(
	Id BIGINT IDENTITY(1,1) PRIMARY KEY,
	UserId VARCHAR(10),
	VideoId VARCHAR(10),
	LikeDate DATE,
	FOREIGN KEY (UserId) REFERENCES Users(Id),
    FOREIGN KEY (VideoId) REFERENCES Video(Id)
);

CREATE TABLE Share (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId VARCHAR(10) NOT NULL,
    VideoId VARCHAR(10) NOT NULL,
    Emails VARCHAR(50),
    ShareDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id),
    FOREIGN KEY (VideoId) REFERENCES Video(Id)
);

INSERT INTO Users (Id, Password, Email, Fullname, Admin) VALUES
('U01', '123456', 'teo@gmail.com', N'Nguy?n V?n Tèo', 0),
('U02', '123456', 'ti@gmail.com', N'Nguy?n V?n Tí', 0),
('U03', '123456', 'hong@gmail.com', N'Lê H?ng', 0),
('U04', '123456', 'lan@gmail.com', N'Tr?n Th? Lan', 0),
('U05', '123456', 'admin@gmail.com', N'Qu?n Tr? 1', 1),
('U06', '123456', 'minh@gmail.com', N'Tr?n Minh', 0),
('U07', '123456', 'ha@gmail.com', N'Ph?m Thu Hà', 0),
('U08', '123456', 'kiet@gmail.com', N'Lý Ki?t', 0),
('U09', '123456', 'vy@gmail.com', N'Ngô Vy', 0),
('U10', '123456', 'duy@gmail.com', N'Hoàng Duy', 0);

INSERT INTO Video (Id, Titile, Poster, Views, Description, Active, Link) VALUES
('V01', N'Top 10 Most Satisfying Footage on the Internet', 'poster1.jpg', 1000000, N'Compilation video', 1, 'https://www.youtube.com/watch?v=Q5gE5ODKsZk'),
('V02', N'How to Learn Java in 2024 (Beginner to Advanced)', 'poster2.jpg', 850000, N'Java tutorial', 1, 'https://www.youtube.com/watch?v=A74TOX803D0'),
('V03', N'Relaxing Piano Music for Study and Sleep', 'poster3.jpg', 5200000, N'Music for relaxation', 1, 'https://www.youtube.com/watch?v=1ZYbU82GVz4'),
('V04', N'10 Linux Tricks Every Developer Should Know', 'poster4.jpg', 340000, N'Linux tips', 1, 'https://www.youtube.com/watch?v=agetfT-ug1E'),
('V05', N'What is Artificial Intelligence? AI in 5 Minutes', 'poster5.jpg', 900000, N'AI explanation', 1, 'https://www.youtube.com/watch?v=2ePf9rue1Ao'),
('V06', N'Marvel Studios’ Avengers: Endgame - Official Trailer', 'poster6.jpg', 135000000, N'Movie trailer', 1, 'https://www.youtube.com/watch?v=hA6hldpSTF8'),
('V07', N'Lofi Hip Hop Radio - Beats to Relax/Study to', 'poster7.jpg', 9999999, N'Lofi beats', 1, 'https://www.youtube.com/watch?v=jfKfPfyJRdk'),
('V08', N'NASA - First Image from the James Webb Telescope', 'poster8.jpg', 7200000, N'Space discovery', 1, 'https://www.youtube.com/watch?v=9t8P3KJtE5s'),
('V09', N'Nhạc Chill TikTok Hay Nhất 2024', 'poster9.jpg', 6000000, N'VN chill music', 1, 'https://www.youtube.com/watch?v=ZcQgYQY2hNw'),
('V10', N'Cách Làm Bánh Mì Việt Nam Giòn Ngon Chuẩn Tiệm', 'poster10.jpg', 4500000, N'Cooking tutorial', 1, 'https://www.youtube.com/watch?v=jWnp_GHSPdE'),
('V11', N'The Most Beautiful Places in the World 4K', 'poster11.jpg', 12000000, N'Nature landscapes', 1, 'https://www.youtube.com/watch?v=WY4k9uG5cKk'),
('V12', N'How to Build a Complete Website with HTML CSS JS', 'poster12.jpg', 700000, N'Web development tutorial', 1, 'https://www.youtube.com/watch?v=G3e-cpL7ofc'),
('V13', N'The History of the Entire World, I Guess', 'poster13.jpg', 80000000, N'Funny history video', 1, 'https://www.youtube.com/watch?v=xuCn8ux2gbs'),
('V14', N'Why We Age – And Why We Don’t Have To', 'poster14.jpg', 6000000, N'Kurzgesagt science video', 1, 'https://www.youtube.com/watch?v=GoJsr4IwCm4'),
('V15', N'Programming Meme Compilation #1', 'poster15.jpg', 5000000, N'Memes about coding', 1, 'https://www.youtube.com/watch?v=6avJHaC3C2U'),
('V16', N'SpaceX Launches Starship Flight Test', 'poster16.jpg', 9000000, N'SpaceX rocket launch', 1, 'https://www.youtube.com/watch?v=Z4TXCZG_NEY'),
('V17', N'Top 100 Funny Cat Videos of the Year', 'poster17.jpg', 30000000, N'Funny cats', 1, 'https://www.youtube.com/watch?v=hY7m5jjJ9mM'),
('V18', N'How to Cook Perfect Steak - Gordon Ramsay', 'poster18.jpg', 25000000, N'Cooking tutorial', 1, 'https://www.youtube.com/watch?v=AmC9SmCBUj4'),
('V19', N'Calming Rain Sounds for Sleeping', 'poster19.jpg', 18000000, N'Rain ambience', 1, 'https://www.youtube.com/watch?v=DW8ZP8kzsD8'),
('V20', N'Python Full Course - Learn Python in 12 Hours', 'poster20.jpg', 4000000, N'Python programming tutorial', 1, 'https://www.youtube.com/watch?v=_uQrJ0TkZlc'),
('V21', N'Why Black Holes Could Delete the Universe', 'poster21.jpg', 15500000, N'Science - black holes', 1, 'https://www.youtube.com/watch?v=QqsLTNkzvaY'),
('V22', N'15 Amazing Science Experiments You Can Do at Home', 'poster22.jpg', 9500000, N'Science experiments', 1, 'https://www.youtube.com/watch?v=jIMihpDmBpY'),
('V23', N'Javascript Crash Course for Beginners', 'poster23.jpg', 2000000, N'JS tutorial', 1, 'https://www.youtube.com/watch?v=hdI2bqOjy3c'),
('V24', N'The BEST Minecraft Build Ideas', 'poster24.jpg', 5000000, N'Minecraft building tips', 1, 'https://www.youtube.com/watch?v=6x0WgB2b2p4'),
('V25', N'90 Minute Timer - Soft Music', 'poster25.jpg', 4500000, N'Study timer', 1, 'https://www.youtube.com/watch?v=4Tr0otuiQuU'),
('V26', N'Velocity Edit Tutorial for Beginners', 'poster26.jpg', 1200000, N'Video editing tutorial', 1, 'https://www.youtube.com/watch?v=8cP7snhFo2E'),
('V27', N'Deep Focus - Study Music for Coding', 'poster27.jpg', 6800000, N'Focus music', 1, 'https://www.youtube.com/watch?v=wp43OdtAAkM'),
('V28', N'Why People Are Leaving Windows for Linux', 'poster28.jpg', 2000000, N'Linux review', 1, 'https://www.youtube.com/watch?v=8C-s9iXHdZk'),
('V29', N'How to Fix Your Posture in 10 Minutes', 'poster29.jpg', 10000000, N'Health tips', 1, 'https://www.youtube.com/watch?v=1mxfH-F1_98'),
('V30', N'Robotics Explained - Future of AI Robots', 'poster30.jpg', 8000000, N'Robotics tech', 1, 'https://www.youtube.com/watch?v=4s8o6cZC3Fs');

INSERT INTO Favorite (UserId, VideoId, LikeDate) VALUES
('U01', 'V01', '2024-01-10'),
('U02', 'V03', '2024-01-12'),
('U03', 'V01', '2024-01-15'),
('U04', 'V05', '2024-01-16'),
('U05', 'V02', '2024-01-18'),
('U06', 'V01', '2024-01-20'),
('U07', 'V03', '2024-01-21'),
('U08', 'V04', '2024-01-22'),
('U09', 'V02', '2024-01-24'),
('U10', 'V05', '2024-01-26');

INSERT INTO Share (UserId, VideoId, Emails, ShareDate) VALUES
('U01', 'V01', 'friend1@gmail.com', '2024-01-05'),
('U02', 'V02', 'friend2@gmail.com', '2024-01-07'),
('U03', 'V03', 'friend3@gmail.com', '2024-01-08'),
('U04', 'V04', 'friend4@gmail.com', '2024-01-09'),
('U05', 'V05', 'friend5@gmail.com', '2024-01-10'),
('U06', 'V06', 'friend6@gmail.com', '2024-01-11'),
('U07', 'V07', 'friend7@gmail.com', '2024-01-12'),
('U08', 'V08', 'friend8@gmail.com', '2024-01-13'),
('U09', 'V09', 'friend9@gmail.com', '2024-01-14'),
('U10', 'V10', 'friend10@gmail.com', '2024-01-15');

