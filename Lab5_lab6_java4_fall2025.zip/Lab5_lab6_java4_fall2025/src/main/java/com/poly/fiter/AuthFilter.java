package com.poly.fiter;


import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.poly.model.User;
@WebFilter(filterName = "AuthFilter" , urlPatterns = {"/Bai3_AccountManagementServlet/*","/Bai3_AccountManagementServlet","/UserServletBai3/*"})
public class AuthFilter implements HttpFilter{

	@Override
	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		String uri = req.getRequestURI();
		User user = (User) req.getSession().getAttribute("user");// dang nhap
		String error = "";
		System.out.println("AuthFilter running");
		if(user == null) {
			error = resp.encodeURL("Please login to use this function!");
			System.out.println("Vui lÃ²ng Ä‘Äƒng nháº­p!");
		}
		else if(!user.getAdmin() && uri.contains("Bai3_AccountManagementServlet")) {
			System.out.println("VUI LÃ’NG Ä�Ä‚NG NHáº¬P Ä�ÃšNG VAI TRÃ’");
			error = resp.encodeURL("Please login with admin role");
			
		}
		if(!error.isEmpty()) 
		{
//			req.getSession().setAttribute("securi", uri);
			req.getSession().setAttribute("securi", error);
			System.out.println("Error!");
			//resp.sendRedirect("accountBai3/sign-in?error="+resp.encodeURL(error));
			resp.sendRedirect("views/login.jsp?error="+resp.encodeURL(error));
			//req.getRequestDispatcher("/views/login.jsp").forward(req, resp);
			
			
		}
		else {
			System.out.println("No Error!");
			chain.doFilter(req, resp);
			// session lÃ†Â°u trÃ¡Â»Â¯ trong khoÃ¡ÂºÂ£ng thÃ¡Â»ï¿½i gian bao lÃƒÂ¢u khi viet ham nay thi khong can phai tao class sessionexpirationfiter va file web.xml
		     req.getSession().setMaxInactiveInterval(40); 
		
			
		}
	}

}
