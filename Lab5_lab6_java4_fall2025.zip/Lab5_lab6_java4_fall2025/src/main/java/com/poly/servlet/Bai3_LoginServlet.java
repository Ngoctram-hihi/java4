package com.poly.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import com.poly.dao.DAO_User;
import com.poly.model.User;
import com.poly.utils.CookieUtils;

@WebServlet({"/accountBai3/sign-in", "/logout"})
public class Bai3_LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String uri = request.getRequestURI();
        if (uri.contains("/logout")) {
            // Xóa session khi logout
            request.getSession().invalidate();

            // Redirect về trang login
            response.sendRedirect(request.getContextPath() + "/accountBai3/sign-in");
            return;
        }

        // Xử lý login page
        Cookie cUser = CookieUtils.get(request, "userID");
        Cookie cPass = CookieUtils.get(request, "passwordID");
        Cookie cRem  = CookieUtils.get(request, "remember");

        if (cUser != null) request.setAttribute("userID", cUser.getValue());
        if (cPass != null) request.setAttribute("passwordID", cPass.getValue());
        if (cRem  != null) request.setAttribute("remember", "true");

        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String id = request.getParameter("userID");
        String pw = request.getParameter("password");
        String remember = request.getParameter("remember");

        DAO_User dao = new DAO_User();
        User user = dao.findByID(id);

        if (user == null) {
            request.setAttribute("message", "Tài khoản không tồn tại");
            request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            return;
        }

        if (!user.getPassword().equals(pw)) {
            request.setAttribute("message", "Sai mật khẩu!");
            request.getRequestDispatcher("/views/login.jsp").forward(request, response);
            return;
        }

        // Đăng nhập thành công
        HttpSession session = request.getSession();
        session.setAttribute("user", user);
        session.setAttribute("messageHomePage", "Đăng nhập thành công");

        if (remember != null) {
            // Lưu cookie 30 ngày
            CookieUtils.add(response, "userID", id, 24 * 30);
            CookieUtils.add(response, "passwordID", pw, 24 * 30);
            CookieUtils.add(response, "remember", "true", 24 * 30);
        } else {
            // Xóa cookie nếu không chọn Remember Me
            CookieUtils.remove(request, response, "userID");
            CookieUtils.remove(request, response, "passwordID");
            CookieUtils.remove(request, response, "remember");
        }

        request.getRequestDispatcher("/views/homepage.jsp").forward(request, response);
    }
}
