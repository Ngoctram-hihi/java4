package com.poly.dao;
import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;

import com.poly.model.User;
import com.poly.utils.*;

public class DAO_User{
	public User checkLogin(String id, String password) {
	    EntityManager em = JpaUtils.getEntityManager();
	    try {
	        String sql = "Select o from User o where o.userID = :userID and o.password = :password";
	        TypedQuery<User> query = em.createQuery(sql, User.class);
	        query.setParameter("userID", id);
	        query.setParameter("password", password);

	        // Lấy danh sách kết quả
	        List<User> list = query.getResultList();
	        if (list.isEmpty()) {
	            return null; // Không tìm thấy -> login thất bại
	        }
	        return list.get(0); // Có kết quả -> login thành công
	    } finally {
	        em.close();
	    }
	}
	
	public User findByID(String id) {
	    EntityManager em = JpaUtils.getEntityManager();
	    try {
	        String sql = "Select o from User o where o.userID = :userID";
	        TypedQuery<User> query = em.createQuery(sql, User.class);
	        query.setParameter("userID", id);

	        // Sử dụng getResultList để tránh NoResultException
	        List<User> list = query.getResultList();
	        if (list.isEmpty()) {
	            return null;
	        }
	        return list.get(0);
	    } finally {
	        em.close();
	    }
	}
	
	public void create(User user) {
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o transaction
		EntityTransaction tran = em.getTransaction();

		try {
			//bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u transaction
			tran.begin();
			// lÃ†Â°u user vÃƒÂ o CSDL
			em.persist(user);
			//ChÃ¡ÂºÂ¥p nhÃ¡ÂºÂ­t kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ thao tÃƒÂ¡c
			tran.commit();
		} catch (Exception e) {
			e.printStackTrace();
			//HuÃ¡Â»Â· thao tÃƒÂ¡c khi cÃƒÂ³ exception
			tran.rollback();
			System.out.println("LÃ¡Â»â€”i trÃƒÂ¹ng ID");
			throw e;
		} finally {
			em.close();
		}

	}

	public void update(User user) {
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o transaction
		EntityTransaction tran = em.getTransaction();
		
		try {
			//bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u transaction
			tran.begin();
			// update user vÃƒÂ o CSDL
			em.merge(user);
			//ChÃ¡ÂºÂ¥p nhÃ¡ÂºÂ­t kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ thao tÃƒÂ¡c
			tran.commit();
		} catch (Exception e) {
			e.printStackTrace();
			//HuÃ¡Â»Â· thao tÃƒÂ¡c khi cÃƒÂ³ exception
			tran.rollback();
			throw e;
		} finally {
			em.close();
		}

	}
	
	public void deleteAll() {
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o transaction
		EntityTransaction tran = em.getTransaction();
		//TÃ¡ÂºÂ¡o cÃƒÂ¢u truy vÃ¡ÂºÂ¥n
		String jqpl = "Delete from User o";
		//TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
		em.createQuery(jqpl).executeUpdate();
	}
	
	public void delete(String id) throws Exception{
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o transaction
		EntityTransaction tran = em.getTransaction();

		try {
			//bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u transaction
			tran.begin();
			// update user vÃƒÂ o CSDL
			User user = em.find(User.class, id);
			//nÃ¡ÂºÂ¿u tÃƒÂ¬m thÃ¡ÂºÂ¥y thÃƒÂ¬ xoÃƒÂ¡ | khÃƒÂ´ng thÃƒÂ¬ khÃƒÂ´ng tÃ¡Â»â€œn tÃ¡ÂºÂ¡i
			if(user != null) {
				em.remove(user);
			}else {
				throw new Exception("This user does not exist!");
			}
			//ChÃ¡ÂºÂ¥p nhÃ¡ÂºÂ­n kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ thao tÃƒÂ¡c
			tran.commit();
		} catch (Exception e) {
			e.printStackTrace();
			//HuÃ¡Â»Â· thao tÃƒÂ¡c khi cÃƒÂ³ exception
			tran.rollback();
			throw e;
		} finally {
			em.close();
		}
	}
	
	public List<User> findAll(){
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//LÃ¡ÂºÂ¥y cÃƒÂ¢u lÃ¡Â»â€¡nh findAll cÃƒÂ³ sÃ¡ÂºÂµn lÃƒÂºc tÃ¡ÂºÂ¡o lÃ¡Â»â€ºp User
		TypedQuery<User> query = em.createNamedQuery("User.findAll", User.class);
		//TrÃ¡ÂºÂ£ vÃ¡Â»ï¿½ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		return query.getResultList();
		
	}
	
	public List<User> findByRole(boolean role){
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o cÃƒÂ¢u lÃ¡Â»â€¡nh truy vÃ¡ÂºÂ¥n
		String jqpl = "Select o from User o where o.admin = :role";
		//TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
		TypedQuery<User> query = em.createQuery(jqpl,User.class);
		query.setParameter("role", role);
		//TrÃ¡ÂºÂ£ vÃ¡Â»ï¿½ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		return query.getResultList();
		
	}
	
	public List<User> findByKeyWord(String keyword){
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o cÃƒÂ¢u truy vÃ¡ÂºÂ¥n
		String jqpl = "Select o from User o where o.fullName like :keyword";
		//TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
		TypedQuery<User> query = em.createQuery(jqpl, User.class);
		query.setParameter("keyword", "%"+keyword+"%");
		//TrÃ¡ÂºÂ£ vÃ¡Â»ï¿½ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		return query.getResultList();
	}
	
	public User findOne(String id, String password){
		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
		EntityManager em = JpaUtils.getEntityManager();
		//TÃ¡ÂºÂ¡o cÃƒÂ¢u truy vÃ¡ÂºÂ¥n
		String jqpl = "Select o from User o where o.userID = :userID and o.password = :password";
		//TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
		TypedQuery<User> query = em.createQuery(jqpl,User.class);
		
		query.setParameter("userID", id);
		query.setParameter("password", password);
		//TrÃ¡ÂºÂ£ vÃ¡Â»ï¿½ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
		return query.getSingleResult();
		
	}
	
//	public User findByID(String id){
//		//TÃ¡ÂºÂ¡o EntityManager Ã„â€˜Ã¡Â»Æ’ bÃ¡ÂºÂ¯t Ã„â€˜Ã¡ÂºÂ§u lÃƒÂ m viÃ¡Â»â€¡c vÃ¡Â»â€ºi CSDL
//		EntityManager em = JpaUtils.getEntityManager();
//		//TÃ¡ÂºÂ¡o cÃƒÂ¢u truy vÃ¡ÂºÂ¥n
//		String jqpl = "Select o from User o where o.id = :id";
//		//TÃ¡ÂºÂ¡o Ã„â€˜Ã¡Â»â€˜i tÃ†Â°Ã¡Â»Â£ng truy vÃ¡ÂºÂ¥n
//		TypedQuery<User> query = em.createQuery(jqpl,User.class);
//		
//		query.setParameter("id", id);
//
//		//TrÃ¡ÂºÂ£ vÃ¡Â»ï¿½ kÃ¡ÂºÂ¿t quÃ¡ÂºÂ£ truy vÃ¡ÂºÂ¥n
//		return query.getSingleResult();
//		
//	}
}
