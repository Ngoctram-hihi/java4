package com.poly.dao;

import java.util.List;

import com.poly.entity.User;

public interface UserDao1 extends TongquatDao<User, String>
{

	
}
