package com.poly.dao;

import java.util.List;

import com.poly.entity.Favorite;
import com.poly.entity.User;
import com.poly.utils.JpaUtils;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;

public class FovoritesDao 
{
	private static EntityManager em = JpaUtils.getEntityManager();
	
	public static List<Favorite> findFavoritesByUserId(String userId) 
	{
        User user = em.find(User.class, userId);  // load user
        if (user == null) {
            return null;
        }
        // Trả về list favorite từ quan hệ @OneToMany
        return user.getFavorites();
    }
	// cách chạy chuẩn hơn/ nhanh hơn jpql
	public static List<Favorite> findFavoritesByUserIdJPQL(String userId) {
	    String jpql = "SELECT f FROM Favorite f WHERE f.user.id = :uid";
	    TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
	    query.setParameter("uid", userId);
	    return query.getResultList();
	}
	
	 public static List<Favorite> findFavoritesByUserIdJPQL1(String userId) {
	        // Sử dụng tham số số ?1 thay vì :uid
	        String jpql = "SELECT f FROM Favorite f WHERE f.user.id = ?1";
	        TypedQuery<Favorite> query = em.createQuery(jpql, Favorite.class);
	        query.setParameter(1, userId); // truyền giá trị vào ?1
	        return query.getResultList();
	    }
	
	 
	
}

